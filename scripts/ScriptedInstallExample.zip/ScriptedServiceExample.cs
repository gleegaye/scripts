using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Security.Cryptography;
using System.ServiceProcess;
using System.Threading;

namespace ScriptedInstallExample
{
	public class ScriptedServiceExample : System.ServiceProcess.ServiceBase
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ScriptedServiceExample(string[] args)
		{
			// This call is required by the Windows.Forms Component Designer.
			InitializeComponent();
		}

		// The main entry point for the process
		static void Main(string[] args)
		{
			System.ServiceProcess.ServiceBase[] ServicesToRun;
	
			// More than one user Service may run within the same process. To add
			// another service to this process, change the following line to
			// create a second service object. For example,
			//
			//   ServicesToRun = new System.ServiceProcess.ServiceBase[] {new MonitoredServiceExample(), new MySecondUserService()};
			//
			ServicesToRun = new System.ServiceProcess.ServiceBase[] { new ScriptedServiceExample(args) };

			System.ServiceProcess.ServiceBase.Run(ServicesToRun);
		}

		#region Service related methods

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
			// Service attributes
			this.CanStop			      = true;
			this.CanPauseAndContinue      = true;
			this.AutoLog			      = true;
			this.ServiceName = "ScriptedServiceExample";
		}

		/// <summary>
		/// Set things in motion so your service can do its work.
		/// </summary>
		protected override void OnStart(string[] args)
		{
			base.OnStart(args);
			// Do nothing

		}
 
		/// <summary>
		/// Stop this service.
		/// </summary>
		protected override void OnStop()
		{
			base.OnStop();
		}

		/// <summary>
		/// Pause the service
		/// </summary>
		protected override void OnPause() 
		{
			base.OnPause();
		}

		/// <summary>
		/// Resume the service
		/// </summary>
		protected override void OnContinue() 
		{
			base.OnContinue();
		}

		#endregion

	}
}
