Imports System.Collections
Imports System.ComponentModel
Imports System.Configuration.Install
Imports System.Collections.Specialized
Imports System.ServiceProcess
Imports Microsoft.Win32

<RunInstaller(True)> _
Public Class ScriptedInstaller
    Inherits Installer

    'This is a custom project installer.
    'Applies a unique name to the service using the /name switch.
    'Sets user name and password using the /user and /password switches.
    'Allows the use of a local account using the /account switch.

    Private Const mServiceName As String = "MonitoredServiceExample"
    Private Const mServiceDescription As String = "Example MonitoredService implementation."

    Private mServiceInstaller As ServiceInstaller
    Private mProcessInstaller As ServiceProcessInstaller

    Public Sub New()

        mServiceInstaller = New ServiceInstaller
        mProcessInstaller = New ServiceProcessInstaller
        mProcessInstaller.Account = System.ServiceProcess.ServiceAccount.User()
        With mServiceInstaller
            .StartType = ServiceStartMode.Manual
            .ServiceName = mServiceName
        End With
        Installers.Add(mServiceInstaller)
        Installers.Add(mProcessInstaller)

    End Sub

    Public Function GetContextParameter(ByVal Key As String) As String

        Dim sValue As String

        Try
            sValue = Me.Context.Parameters(Key).ToString
        Catch ex As Exception
            sValue = ""
        End Try
        Return sValue

    End Function

    Protected Overrides Sub OnBeforeInstall(ByVal SavedState As IDictionary)

        'This method is run before the install process.
        'This method is overriden to set the following parameters:
        '    service name (/name switch)
        '    account type (/account switch)
        '    for a user account user name (/user switch)
        '    for a user account password (/password switch)
        'Note that when using a user account, if the user name or password 
is not set,
        'the installing user is prompted for the credentials to use.

        Dim bIsUserAccount As Boolean = False
        Dim sName As String = ""
        Dim sAcct As String = ""
        Dim sUsername As String = ""
        Dim sPassword As String = ""

        MyBase.OnBeforeInstall(SavedState)
        'Decode the command line switches
        sName = GetContextParameter("name")
        mServiceInstaller.ServiceName = sName

        'What type of credentials to use to run the service
        'The default is User
        sAcct = GetContextParameter("account")
        If sAcct.Length = 0 Then
            sAcct = "user"
        End If
        'Decode the type of account to use
        Select Case sAcct
            Case "user"
                mProcessInstaller.Account = ServiceAccount.User
                bIsUserAccount = True
            Case "localservice"
                mProcessInstaller.Account = ServiceAccount.LocalService
            Case "localsystem"
                mProcessInstaller.Account = ServiceAccount.LocalSystem
            Case "networkservice"
                mProcessInstaller.Account = ServiceAccount.NetworkService
            Case Else
                mProcessInstaller.Account = ServiceAccount.User
                bIsUserAccount = True
        End Select

        'User name and password
        sUsername = GetContextParameter("user")
        sPassword = GetContextParameter("password")

        'Should I use a user account?
        If bIsUserAccount Then
            'If we need to use a user account, set the user name and password()
            mProcessInstaller.Username = sUsername
            mProcessInstaller.Password = sPassword
        End If

    End Sub

    Public Overrides Sub Install(ByVal StateServer As IDictionary)

        'Modify the registry to install the new service

        Dim rkSystem As RegistryKey
        'HKEY_LOCAL_MACHINE\Services\CurrentControlSet
        Dim rkCurrentControlSet As RegistryKey
        '...\Services
        Dim rkServices As RegistryKey
        '...\<Service Name>
        Dim rkService As RegistryKey
        '...\Parameters - this is where you can put service-specific Configuration()
        Dim rkConfig As RegistryKey
        Dim sImagePath As String = ""

        MyBase.Install(StateServer)
        'Define the registry keys
        'Navigate to services
        rkSystem = Registry.LocalMachine.OpenSubKey("System")
        rkCurrentControlSet = rkSystem.OpenSubKey("CurrentControlSet")
        rkServices = rkCurrentControlSet.OpenSubKey("Services")
        'Add the service
        rkService = rkServices.OpenSubKey(mServiceInstaller.ServiceName, True)
        'Default service description
        rkService.SetValue("Description", mServiceDescription)
        'Display the assembly image path and modify to add the service name
        'The executable then strips the name out of the image
        Console.WriteLine("ImagePath: " & CType(rkService.GetValue("ImagePath"), String))
        sImagePath = CType(rkService.GetValue("ImagePath"), String)
        sImagePath &= " -s" & mServiceInstaller.ServiceName
        rkService.SetValue("ImagePath", sImagePath)
        'Create a parameters subkey
        rkConfig = rkService.CreateSubKey("Parameters")
        'Close keys
        rkConfig.Close()
        rkService.Close()
        rkServices.Close()
        rkCurrentControlSet.Close()
        rkSystem.Close()

    End Sub

    Protected Overrides Sub OnBeforeUninstall(ByVal SavedState As IDictionary)

        'Uninstall based on the service name

        MyBase.OnBeforeUninstall(SavedState)
        'Set the service name based on the command line
        mServiceInstaller.ServiceName = GetContextParameter("name")

    End Sub

    Public Overrides Sub Uninstall(ByVal StateServer As IDictionary)

        'Modify the registry to remove the service

        Dim rkSystem As RegistryKey
        'HKEY_LOCAL_MACHINE\Services\CurrentControlSet
        Dim rkCurrentControlSet As RegistryKey
        '...\Services
        Dim rkServices As RegistryKey
        '...\<Service Name>
        Dim rkService As RegistryKey
        '...\Parameters - this is where you can put service-specific Configuration()

        MyBase.Uninstall(StateServer)
        'Navigate down the registry path
        rkSystem = Registry.LocalMachine.OpenSubKey("System")
        rkCurrentControlSet = rkSystem.OpenSubKey("CurrentControlSet")
        rkServices = rkCurrentControlSet.OpenSubKey("Services")
        rkService = rkServices.OpenSubKey(mServiceInstaller.ServiceName, True)
        'Remove the parameters key
        rkService.DeleteSubKeyTree("Parameters")
        'Close keys
        rkService.Close()
        rkServices.Close()
        rkCurrentControlSet.Close()
        rkSystem.Close()

    End Sub

End Class
